<?php

if (isset ($_POST['auth'])) { $passw = $_POST['auth']; }

if ($passw = 'duster12')
{
   return TRUE;
}
else
{
   return FALSE;
}

?>


<?php
//DB Variables
$db_name = 'accounts';
$fieldsDBname = 'fields';
$db_host = 'localhost';
$db_user = 'xtac';
$db_pass = 'lamp2010';

// LDAP Variables:
$ldap_url = 'ldap.svsu.edu';
$base = 'o=svsu';
$ldap_user = 'cn=accountballookup,ou=linux,o=svsu';
$ldap_pass = 'qwerty';

$pw_user = 'cn=pwadmin,ou=Labs,o=svsu';
$pw_pass = 'Y2hlZXJjaG93';

?>
